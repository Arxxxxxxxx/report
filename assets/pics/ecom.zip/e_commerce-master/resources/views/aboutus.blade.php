@extends('templat.layout')

@section('content')
<br>
<br>
<!-- ####################################### -->

<!-- web content -->
<div class="web_content">
<!-- website all post section -->
    <div class="web_post">
    
<div class="txt_p">
<br>
<p class="font-defult">
 {{__('privcytext')}}
</p>


<br>
<br>
</div>
<div class="rec">
  </div>

  <br><br>

@endsection
